<?php
namespace app\modules\administration\controllers;
use app\config\widgets\Controller;
class UpdatesController extends Controller {
    public function actionIndex() {
        return $this->renderView([]);
    }
}