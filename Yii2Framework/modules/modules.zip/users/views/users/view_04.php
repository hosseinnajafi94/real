<?php
use yii\bootstrap4\Html;
/* @var $this yii\web\View */
/* @var $model app\modules\users\models\DAL\Users */
?>
<p>
    <?= Html::a(Yii::t('app', 'Create'), ['create'], ['class' => 'btn btn-sm btn-success']) ?>
</p>