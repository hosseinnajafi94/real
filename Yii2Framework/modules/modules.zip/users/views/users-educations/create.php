<?php
/* @var $this yii\web\View */
/* @var $model app\modules\users\models\DAL\UsersEducations */
$this->title = Yii::t('app', 'Create');
?>
<div class="users-users-educations-create">
    <?= $this->render('_form', [
        'model' => $model
    ]) ?>
</div>