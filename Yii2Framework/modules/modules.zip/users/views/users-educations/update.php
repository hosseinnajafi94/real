<?php
/* @var $this yii\web\View */
/* @var $model app\modules\users\models\DAL\UsersEducations */
$this->title = Yii::t('app', 'Update');
?>
<div class="users-users-educations-update">
    <?= $this->render('_form', [
        'model' => $model
    ]) ?>
</div>