<?php
/* @var $this yii\web\View */
//$this->params['breadcrumbs'][] = ['label' => 'asd', 'url' => ['/site/default/index']];
//$this->params['breadcrumbs'][] = 'www';
$this->title = Yii::t('app', 'Home');
?>
<div class="site-index">

</div>
