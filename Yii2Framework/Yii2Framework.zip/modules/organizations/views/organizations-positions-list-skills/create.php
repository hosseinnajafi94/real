<?php
/* @var $this yii\web\View */
/* @var $model app\modules\organizations\models\VML\OrganizationsPositionsListSkillsVML */
//$this->title = Yii::t('organizations', 'Create Organizations Positions List Skills');
//$this->params['breadcrumbs'][] = ['label' => Yii::t('organizations', 'Organizations Positions List Skills'), 'url' => ['index']];
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="organizations-positions-list-skills-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>