<?php
namespace app\modules\organizations\models\VML;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\modules\organizations\models\DAL\OrganizationsPlanning;
class OrganizationsPlanningSearchVML extends OrganizationsPlanning {
    public $myPageSize = 10;
    public function rules() {
        return [
                [['id', 'organization_id', 'type_id', 'parent_id', 'created_by', 'updated_by', 'myPageSize'], 'integer'],
                [['title', 'description', 'created_at', 'updated_at'], 'safe'],
        ];
    }
    public function scenarios() {
        return Model::scenarios();
    }
    public function search($org_id, $params) {
        $query = OrganizationsPlanning::find()->where(['organization_id' => $org_id]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => ['defaultPageSize' => 10]
        ]);
        $this->load($params);
        if (!$this->validate()) {
            $query->where('0=1');
            return $dataProvider;
        }
        $query->andWhere(['parent_id' => $this->parent_id]);
        $dataProvider->pagination->pageSize = $this->myPageSize;
        $query->andFilterWhere([
            'id'              => $this->id,
            'organization_id' => $this->organization_id,
            'type_id'         => $this->type_id,
            'created_at'      => $this->created_at,
            'created_by'      => $this->created_by,
            'updated_at'      => $this->updated_at,
            'updated_by'      => $this->updated_by,
        ]);
        $query->andFilterWhere(['like', 'title', $this->title])
                ->andFilterWhere(['like', 'description', $this->description]);
        return $dataProvider;
    }
}