<?php
return [
    'Create' => 'ارسال تیکت جدید',
    'Answer' => 'پاسخ',
    'Close' => 'بستن',
    'Tickets' => 'تیکت ها',
    'ID' => 'شناسه',
    'Title' => 'عنوان',
    'Support ID' => 'بخش',
    'Status ID' => 'وضعیت',
    'Datetime' => 'آخرین ارسال',
    'Receiver ID' => 'گیرنده',
    'Message' => 'متن پیام',
    'File' => 'فایل ضمیمه',
    'Are you sure you want to delete this item?' => 'آیا اطمینان دارید؟',
    'Sender ID' => 'فرستنده',
    'Category ID' => 'دسته بندی - ماژول',
    '' => '',
];