<?php
return [
    'Provinces' => 'استان ها',
    'Cities' => 'شهر ها',
    'Title' => 'عنوان',
    'Province ID' => 'استان',
];