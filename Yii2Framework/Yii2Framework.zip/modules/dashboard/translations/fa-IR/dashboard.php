<?php
return [
    'Dashboard' => 'داشبورد',
];
