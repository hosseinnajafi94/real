<?php
/* @var $this yii\web\View */
$this->params['breadcrumbs'][] = Yii::t('dashboard', 'Dashboard');
$this->title = Yii::t('dashboard', 'Dashboard');
?>
<div class="dashboard-default-index">
    <div class="row">
        <div class="col-xl-4 col-lg-6 col-md-6 col-12">
            <div class="card bg-white">
                <div class="card-body">
                    <div class="card-block pt-2 pb-0">
                        <div class="media">
                            <div class="media-body white text-left">
                                <h4 class="font-medium-5 card-title mb-0">5789 تومان</h4>
                                <span class="grey darken-1">مجموع بازدید ها</span>
                            </div>
                            <div class="media-right text-right">
                                <i class="icon-cup font-large-1 primary"></i>
                            </div>
                        </div>
                    </div>
                    <div id="Widget-line-chart" class="height-150 lineChartWidget WidgetlineChart mb-2">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 col-md-6 col-12">
            <div class="card bg-white">
                <div class="card-body">
                    <div class="card-block pt-2 pb-0">
                        <div class="media">
                            <div class="media-body white text-left">
                                <h4 class="font-medium-5 card-title mb-0">4567 تومان</h4>
                                <span class="grey darken-1">کل فروش</span>
                            </div>
                            <div class="media-right text-right">
                                <i class="icon-wallet font-large-1 warning"></i>
                            </div>
                        </div>
                    </div>
                    <div id="Widget-line-chart1" class="height-150 lineChartWidget WidgetlineChart1 mb-2">
                    </div>

                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 col-md-6 col-12">
            <div class="card bg-white">
                <div class="card-body">
                    <div class="card-block pt-2 pb-0">
                        <div class="media">
                            <div class="media-body white text-left">
                                <h4 class="font-medium-5 card-title mb-0">9822 تومان</h4>
                                <span class="grey darken-1">ارزش کل</span>
                            </div>
                            <div class="media-right text-right">
                                <i class="icon-basket-loaded font-large-1 success"></i>
                            </div>
                        </div>
                    </div>
                    <div id="Widget-line-chart2" class="height-150 lineChartWidget WidgetlineChart2 mb-2">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row match-height">
        <div class="col-xl-8 col-lg-12 col-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-success">
                        <h4 class="card-title">ارزیابی محصول</h4>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card-block">
                        <div id="line-chart" class="height-300 lineChart lineChartShadow">						
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-12 col-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-danger">
                        <h4 class="card-title">فعالیت های امروز</h4>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-12 timeline-left" id="activity">
                        <div class="timeline">
                            <ul class="list-unstyled base-timeline activity-timeline">
                                <li class="">
                                    <div class="timeline-icon bg-danger">
                                        <i class="fa fa-tasks"></i>
                                    </div>
                                    <div class="act-time">امروز</div>
                                    <div class="base-timeline-info">
                                        <a href="#" class="text-uppercase text-danger">وظیفه اضافه شده است</a>
                                    </div>
                                    <small class="text-muted">
                                        25 دقیقه پیش
                                    </small>
                                </li>
                                <li class="">
                                    <div class="timeline-icon bg-primary">
                                        <i class="fa fa-handshake-o"></i>
                                    </div>
                                    <div class="act-time">دیروز</div>
                                    <div class="base-timeline-info">
                                        <a href="#" class="text-uppercase text-primary">معامله اضافه شده</a>
                                    </div>
                                    <small class="text-muted">
                                        23 ساعت پیش
                                    </small>
                                </li>
                                <li class="">
                                    <div class="timeline-icon bg-dark">
                                        <i class="fa fa-tasks"></i>
                                    </div>
                                    <div class="act-time">09 مهر</div>
                                    <div class="base-timeline-info">
                                        <a href="#" class="text-uppercase text-dark">وظیفه به روز شده است</a>
                                    </div>
                                    <small class="text-muted">
                                        15 روز پیش
                                    </small>
                                </li>
                                <li class="">
                                    <div class="timeline-icon bg-warning">
                                        <i class="fa fa-handshake-o"></i>
                                    </div>
                                    <div class="act-time">04 مهر</div>
                                    <div class="base-timeline-info">
                                        <a href="#" class="text-uppercase text-warning">وظیفه شروع شده است</a>
                                    </div>
                                    <small class="text-muted">
                                        20 روز پیش
                                    </small>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row match-height">
        <div class="col-xl-4 col-lg-12 col-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-warning">
                        <h4 class="card-title">حراجی</h4>
                    </div>
                </div>
                <div class="card-body">
                    <p class="font-medium-2 text-muted text-center pb-2">آخرین 12 ماه فروش</p>
                    <div id="Stack-bar-chart" class="height-300 Stackbarchart mb-2">				
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-8" id="recent-sales">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-primary">
                        <h4 class="card-title">خریداران اخیر
                        </h4>
                    </div>
                    <a class="heading-elements-toggle">
                        <i class="la la-ellipsis-v font-medium-3"></i>
                    </a>
                </div>
                <div class="card-content mt-1">
                    <div class="table-responsive">
                        <table class="table table-hover table-xl mb-0" id="recent-orders">
                            <thead>
                                <tr>
                                    <th class="border-top-0">محصول</th>
                                    <th class="border-top-0">مشتریان
                                    </th>
                                    <th class="border-top-0">دسته بندی ها</th>
                                    <th class="border-top-0">محبوبیت</th>
                                    <th class="border-top-0">میزان</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-truncate">آیفون</td>
                                    <td class="text-truncate">رضا</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-danger round mb-0" type="button">موبایل</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" aria-valuenow="85" aria-valuemin="20" aria-valuemax="100" style="width:85%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate"> 1200.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">سامسونگ</td>
                                    <td class="text-truncate">علی</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-success round mb-0" type="button">تبلت</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-success" role="progressbar" aria-valuenow="75" aria-valuemin="20" aria-valuemax="100" style="width:75%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate">1190.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">آیفون X</td>
                                    <td class="text-truncate">نیما</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-danger round mb-0" type="button">موبایل</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" aria-valuenow="70" aria-valuemin="20" aria-valuemax="100" style="width:70%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate"> 999.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">سامسونگ</td>
                                    <td class="text-truncate">سینا</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-success round mb-0" type="button">تبلت</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-success" role="progressbar" aria-valuenow="60" aria-valuemin="20" aria-valuemax="100" style="width:60%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate"> 1150.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">هوآووی</td>
                                    <td class="text-truncate">سمانه</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-danger round mb-0" type="button">موبایل</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" aria-valuenow="45" aria-valuemin="20" aria-valuemax="100" style="width:45%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate"> 1180.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">هوآووی</td>
                                    <td class="text-truncate">سمانه</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-danger round mb-0" type="button">موبایل</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" aria-valuenow="45" aria-valuemin="20" aria-valuemax="100" style="width:45%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate"> 1180.00 تومان</td>
                                </tr>
                                <tr>
                                    <td class="text-truncate">تکنو</td>
                                    <td class="text-truncate">تینا</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-danger round mb-0" type="button">موبایل</button>
                                    </td>
                                    <td>
                                        <div class="box-shadow-2 mt-1">
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" aria-valuenow="45" aria-valuemin="20" aria-valuemax="100" style="width:45%"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-truncate">1080.00 تومان</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row match-height">
        <div class="col-xl-6 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-primary">
                        <h4 class="card-title">آمار محصولات</h4>
                    </div>
                </div>
                <div class="card-body">

                    <p class="font-medium-2 text-muted text-center">سرگرمی</p>
                    <div id="bar-chart" class="height-250 BarChartShadow BarChart">					
                    </div>

                    <div class="card-block">
                        <div class="row">
                            <div class="col text-center">
                                <span class="gradient-pomegranate d-block rounded-circle mx-auto mb-2" style="width:10px; height:10px;"></span>
                                <span class="font-large-1 d-block mb-2">48</span>
                                <span>ورزشی</span>
                            </div>
                            <div class="col text-center">
                                <span class="gradient-green-tea d-block rounded-circle mx-auto mb-2" style="width:10px; height:10px;"></span>
                                <span class="font-large-1 d-block mb-2">9</span>
                                <span>موزیک</span>
                            </div>
                            <div class="col text-center">
                                <span class="gradient-blackberry d-block rounded-circle mx-auto mb-2" style="width:10px; height:10px;"></span>
                                <span class="font-large-1 d-block mb-2">26</span>
                                <span>مسافرت</span>
                            </div>
                            <div class="col text-center">
                                <span class="gradient-ibiza-sunset d-block rounded-circle mx-auto mb-2" style="width:10px; height:10px;"></span>
                                <span class="font-large-1 d-block mb-2">17</span>
                                <span>اخبار</span>
                            </div>
                            <div class="col text-center">
                                <span class="gradient-back-to-earth d-block rounded-circle mx-auto mb-2" style="width:10px; height:10px;"></span>
                                <span class="font-large-1 d-block mb-2">52</span>
                                <span>وبلاگ</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title-wrap bar-warning">
                        <h4 class="card-title">آمار پروژه</h4>
                    </div>
                </div>
                <div class="card-body">

                    <p class="font-medium-2 text-muted text-center">وظایف پروژه</p>
                    <div id="donut-dashboard-chart" class="height-250 donut donutShadow">
                    </div>

                    <div class="card-block">
                        <div class="row my-3">
                            <div class="col">
                                <span class="mb-1 text-muted d-block">23٪ - شروع شده است</span>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar gradient-blackberry" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="col">
                                <span class="mb-1 text-muted d-block">35٪ - در حال پیشرفت است</span>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar gradient-pomegranate" role="progressbar" style="width: 80%;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="col">
                                <span class="mb-1 text-muted d-block">14٪ - انجام شده است</span>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar gradient-green-tea" role="progressbar" style="width: 60%;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php

$this->registerJsFile('@web/themes/admin/js/dashboard-ecommerce.js', ['depends'=> \app\assets\AdminAsset::class]);