<?php
use yii\helpers\Html;
use app\config\widgets\GridView;
/* @var $this yii\web\View */
/* @var $searchModel \app\modules\users\models\VML\UsersSearchVML */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->params['breadcrumbs'][] = Yii::t('users', 'Users');
?>
<div class="users-users-index box">
    <div class="box-header"><?= Yii::t('users', 'Users') ?></div>
    <p>
        <?= Html::a(Yii::t('app', 'Create'), ['create'], ['class' => 'btn btn-sm btn-success']) ?>
    </p>
    <div class="table-responsive">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],
                'fname',
                'lname',
                'mobile',
                'codemelli',
                'cardmelli_confirmed:bool',
                'avatar_confirmed:bool',
                //'group_id',
                //'status_id',
                //'username',
                //'password_hash',
                // 'password_reset_token',
                // 'auth_key',
                // 'avatar',
                // 'email:email',
                // 'province_id:province',
                // 'city_id',
                // 'codeposti',
                // 'address',
                // 'cardmelli',
                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]) ?>
    </div>
</div>