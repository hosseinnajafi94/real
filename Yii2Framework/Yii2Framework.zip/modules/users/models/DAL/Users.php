<?php
namespace app\modules\users\models\DAL;
use Yii;
use app\modules\safes\models\DAL\Safes;
use app\modules\safes\models\DAL\SafesLogs;
use app\modules\safes\models\DAL\SafesMessages;
use app\modules\safes\models\DAL\SafesProtests;
use app\modules\geo\models\DAL\GeoProvinces;
use app\modules\geo\models\DAL\GeoCities;
/**
 * This is the model class for table "users".
 * @author Hossein Najafi <hnajafi1994@gmail.com>
 *
 * @property int $id
 * @property int $group_id
 * @property int $status_id
 * @property string $codemelli
 * @property string $mobile
 * @property string $username
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $auth_key
 * @property string $avatar
 * @property string $email
 * @property string $fname
 * @property string $lname
 * @property int $province_id
 * @property int $city_id
 * @property string $codeposti
 * @property string $address
 * @property string $cardmelli
 * @property bool $cardmelli_confirmed
 * @property bool $avatar_confirmed
 *
 * @property Safes[] $safes
 * @property Safes[] $safes0
 * @property SafesLogs[] $safesLogs
 * @property SafesMessages[] $safesMessages
 * @property SafesProtests[] $safesProtests
 * @property UsersStatuses $status
 * @property UsersGroups $group
 * @property GeoProvinces $province
 * @property GeoCities $city
 * @property UsersAccounts[] $usersAccounts
 * @property UsersBanks[] $usersBanks
 * @property UsersClearing[] $usersClearings
 * @property UsersPayments[] $usersPayments
 */
class Users extends \yii\db\ActiveRecord {
    public static function tableName() {
        return 'users';
    }
    public function rules() {
        return [
                [['group_id', 'status_id', 'codemelli', 'mobile', 'username', 'password_hash', 'auth_key'], 'required'],
                [['group_id', 'status_id', 'province_id', 'city_id'], 'integer'],
                [['cardmelli_confirmed', 'avatar_confirmed'], 'boolean'],
                [['codemelli', 'codeposti'], 'string', 'max' => 10],
                [['mobile', 'username', 'password_hash', 'password_reset_token', 'avatar', 'email', 'fname', 'lname', 'address', 'cardmelli'], 'string', 'max' => 255],
                [['auth_key'], 'string', 'max' => 32],
                [['auth_key'], 'unique'],
                [['username'], 'unique'],
                [['codemelli'], 'unique'],
                [['status_id'], 'exist', 'skipOnError' => true, 'targetClass' => UsersStatuses::className(), 'targetAttribute' => ['status_id' => 'id']],
                [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => UsersGroups::className(), 'targetAttribute' => ['group_id' => 'id']],
                [['province_id'], 'exist', 'skipOnError' => true, 'targetClass' => GeoProvinces::className(), 'targetAttribute' => ['province_id' => 'id']],
                [['city_id'], 'exist', 'skipOnError' => true, 'targetClass' => GeoCities::className(), 'targetAttribute' => ['city_id' => 'id']],
        ];
    }
    public function attributeLabels() {
        return [
            'id' => Yii::t('users', 'ID'),
            'group_id' => Yii::t('users', 'Group ID'),
            'status_id' => Yii::t('users', 'Status ID'),
            'codemelli' => Yii::t('users', 'Codemelli'),
            'mobile' => Yii::t('users', 'Mobile'),
            'username' => Yii::t('users', 'Username'),
            'password_hash' => Yii::t('users', 'Password Hash'),
            'password_reset_token' => Yii::t('users', 'Password Reset Token'),
            'auth_key' => Yii::t('users', 'Auth Key'),
            'avatar' => Yii::t('users', 'Avatar'),
            'email' => Yii::t('users', 'Email'),
            'fname' => Yii::t('users', 'Fname'),
            'lname' => Yii::t('users', 'Lname'),
            'province_id' => Yii::t('users', 'Province ID'),
            'city_id' => Yii::t('users', 'City ID'),
            'codeposti' => Yii::t('users', 'Codeposti'),
            'address' => Yii::t('users', 'Address'),
            'cardmelli' => Yii::t('users', 'Cardmelli'),
            'cardmelli_confirmed' => Yii::t('users', 'Cardmelli Confirmed'),
            'avatar_confirmed' => Yii::t('users', 'Avatar Confirmed'),
        ];
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSafes() {
        return $this->hasMany(Safes::className(), ['buyer_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSafes0() {
        return $this->hasMany(Safes::className(), ['seller_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSafesLogs() {
        return $this->hasMany(SafesLogs::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSafesMessages() {
        return $this->hasMany(SafesMessages::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSafesProtests() {
        return $this->hasMany(SafesProtests::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatus() {
        return $this->hasOne(UsersStatuses::className(), ['id' => 'status_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup() {
        return $this->hasOne(UsersGroups::className(), ['id' => 'group_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProvince() {
        return $this->hasOne(GeoProvinces::className(), ['id' => 'province_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity() {
        return $this->hasOne(GeoCities::className(), ['id' => 'city_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsersAccounts() {
        return $this->hasMany(UsersAccounts::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsersBanks() {
        return $this->hasMany(UsersBanks::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsersClearings() {
        return $this->hasMany(UsersClearing::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsersPayments() {
        return $this->hasMany(UsersPayments::className(), ['user_id' => 'id']);
    }
}